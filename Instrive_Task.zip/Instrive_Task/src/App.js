import logo from './logo.svg';
import './App.css';
import StepperForm from './StepperForm'

function App() {
  return (
    <div className="App">
     <StepperForm/>
    </div>
  );
}

export default App;
