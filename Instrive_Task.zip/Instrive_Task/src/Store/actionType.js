export const step1 = (data) => {
return{
    type: 'STEP1',
    payload: data
}
}

export const step2 = (data) => {
    return{
        type: 'STEP2',
        payload: data
    }
    }