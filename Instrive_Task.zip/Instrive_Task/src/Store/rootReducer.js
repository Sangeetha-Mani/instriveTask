const initalState = {
    firstName: null,
    lastName:null,
    email:null,
    phone:null,
    addressLine1:null,
    addressLine2:null,
    city:null,
    state:null,
    country:null,
    pincode:null


}

export const rootReducer = (state=initalState,action) => {
    switch(action.type){
        case 'STEP1' : {
            console.log(action.payload,'update the store by step1')
            return {...state,firstName:action.payload.firstName,
                lastName:action.payload.lastName,
                email:action.payload.email,
                phone:action.payload.phone }}

        case 'STEP2' : 
        console.log(action.payload,'update the store by step1')
        return {...state, addressLine1:action.payload.addressLine1,
            addressLine2:action.payload.addressLine2,
            city:action.payload.city,
            state:action.payload.state ,
            country:action.payload.country ,
            pincode:action.payload.pincode 

        }
        default: return state
    }
}

