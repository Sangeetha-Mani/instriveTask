import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepButton from '@material-ui/core/StepButton';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';



import { useFormik } from 'formik';
import * as Yup from 'yup';
import {useDispatch , useSelector} from 'react-redux';
import {step1 , step2} from './Store/actionType';
import axios from 'axios';

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
  },
  button: {
    marginRight: theme.spacing(1),
  },
  backButton: {
    marginRight: theme.spacing(1),
  },
  completed: {
    display: 'inline-block',
  },
  instructions: {
    marginTop: theme.spacing(1),
    marginBottom: theme.spacing(1),
  },
}));

function getSteps() {
  return ['Step 1', 'Step 1', 'Preview the Steps'];
}

// formik validation
const phoneRegExp = /^(\+0?1\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$/





export default function HorizontalNonLinearAlternativeLabelStepper() {
  const classes = useStyles();
  const [activeStep, setActiveStep] = React.useState(0);
  const [completed, setCompleted] = React.useState(new Set());
  const [skipped, setSkipped] = React.useState(new Set());
  const steps = getSteps();
  const dispatch = useDispatch();
  const {firstName,lastName,email,phone} = useSelector((state)=> state);
  console.log(firstName,'from state')
  const formik = useFormik({
    initialValues:{
        firstName: '',
        lastName: '',
        email: '',
        phone:''
      },
    validationSchema:Yup.object({
        firstName: Yup.string()
          .max(15, 'Must be 15 characters or less')
          .required('Required'),
        lastName: Yup.string()
          .max(20, 'Must be 20 characters or less')
          .required('Required'),
        email: Yup.string().email('Invalid email address').required('Required'),
        phone:Yup.string().required('Required')
      }),
    onSubmit: (values) => {
        console.log(values,'test')
        //let  result =Object.keys(values).map((key) => ( { key : values[key]}));
       // console.log(result,'onsubmit');
        dispatch(step1(values))
    }
});

const handleEdit = () => {
  const newActiveStep =
  isLastStep() && !allStepsCompleted()
    ? // It's the last step, but not all steps have been completed
      // find the first step that has been completed
      steps.findIndex((step, i) => !completed.has(i))
    : activeStep + 1;

setActiveStep(newActiveStep);
}
  function getStepContent(step) {
  
    switch (step) {
      case 0:
        return(<div>
           <form onSubmit={formik.handleSubmit}>
          <label htmlFor="firstName">First Name</label>
          <input
            id="firstName"
            name="firstName"
            type="text"
            onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              value={formik.values.firstName}
          />
          {formik.touched.firstName && formik.errors.firstName ? (
            <div>{formik.errors.firstName}</div>
          ) : null}
        <br/>
          <label htmlFor="lastName">Last Name</label>
          <input id="lastName" type="text" {...formik.getFieldProps('lastName')} />
          {formik.touched.lastName && formik.errors.lastName ? (
            <div>{formik.errors.lastName}</div>
          ) : null}
    <br/>
          <label htmlFor="email">Email Address</label>
          <input id="email" type="email" {...formik.getFieldProps('email')} />
          {formik.touched.email && formik.errors.email ? (
            <div>{formik.errors.email}</div>
          ) : null}
  <br/>
          <label htmlFor="phone">PhoneNumber</label>
          <input id="phone" type="text" {...formik.getFieldProps('phone')} />
          {formik.touched.phone && formik.errors.phone ? (
            <div>{formik.errors.phone}</div>
          ) : null}
    <br/>
          <button type="submit">Submit</button>
        </form>
        </div>);
      case 1:
        return   (<div>
          <form onSubmit={formik.handleSubmit}>
         <label htmlFor="address1">Addres Line1</label>
         <input
           id="address1"
           name="address1"
           type="text"
           onChange={formik.handleChange}
             onBlur={formik.handleBlur}
             value={formik.values.address1}
         />
         {formik.touched.address1 && formik.errors.address1 ? (
           <div>{formik.errors.address1}</div>
         ) : null}
       <br/>
         <label htmlFor="address2">Address2</label>
         <input id="address2" type="text" name='address2' {...formik.getFieldProps('address2')} />
         {formik.touched.address2 && formik.errors.address2 ? (
           <div>{formik.errors.address2}</div>
         ) : null}
   <br/>
         <label htmlFor="city">City</label>
         <input id="city" type="text" name='city' {...formik.getFieldProps('city')} />
         {formik.touched.city && formik.errors.city ? (
           <div>{formik.errors.city}</div>
         ) : null}
 <br/>
         <label htmlFor="state">PhoneNumber</label>
         <input id="state" type="text" name='state' {...formik.getFieldProps('state')} />
         {formik.touched.phone && formik.errors.phone ? (
           <div>{formik.errors.state}</div>
         ) : null}
   <br/>
   <label htmlFor="country">PhoneNumber</label>
         <input id="country" type="text" name='country' {...formik.getFieldProps('country')} />
         {formik.touched.country && formik.errors.country ? (
           <div>{formik.errors.country}</div>
         ) : null}
   <br/>
   <label htmlFor="pincode">PhoneNumber</label>
         <input id="pincode" type="number" name='pincode' {...formik.getFieldProps('pincode')} />
         {formik.touched.pincode && formik.errors.pincode ? (
           <div>{formik.errors.pincode}</div>
         ) : null}
   <br/>
         <button type="submit">Submit</button>
       </form>
       </div>);
      case 2:
        return (<div>  
          <h1>Step 1 Data</h1>
          <ul>
          <li>FirstName: {firstName}</li>
          <li>LastName: {lastName}</li>
          <li>Email: {email}</li>
          <li>Phone: {phone}</li>
          </ul>
          <button onClick={handleEdit}>Edit</button>
          </div>)
       
       
      default:
        return 'Unknown step';
    }
  }
  const totalSteps = () => {
    return getSteps().length;
  };

  const isStepOptional = (step) => {
    return step === 1;
  };

  const handleSkip = () => {
    if (!isStepOptional(activeStep)) {
      // You probably want to guard against something like this
      // it should never occur unless someone's actively trying to break something.
      throw new Error("You can't skip a step that isn't optional.");
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped((prevSkipped) => {
      const newSkipped = new Set(prevSkipped.values());
      newSkipped.add(activeStep);
      return newSkipped;
    });
  };

  const skippedSteps = () => {
    return skipped.size;
  };

  const completedSteps = () => {
    return completed.size;
  };

  const allStepsCompleted = () => {
    return completedSteps() === totalSteps() - skippedSteps();
  };

  const isLastStep = () => {
    return activeStep === totalSteps() - 1;
  };

  const handleNext = () => {
    const newActiveStep =
      isLastStep() && !allStepsCompleted()
        ? // It's the last step, but not all steps have been completed
          // find the first step that has been completed
          steps.findIndex((step, i) => !completed.has(i))
        : activeStep + 1;

    setActiveStep(newActiveStep);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStep = (step) => () => {
    setActiveStep(step);
  };

  const handleComplete = async() => {
    const newCompleted = new Set(completed);
    newCompleted.add(activeStep);
    setCompleted(newCompleted);
    console.log('complete ')


    /**
     * Sigh... it would be much nicer to replace the following if conditional with
     * `if (!this.allStepsComplete())` however state is not set when we do this,
     * thus we have to resort to not being very DRY.
     */
    if (completed.size !== totalSteps() - skippedSteps()) {
      console.log('finish')
      handleNext();
    }
    //making api call 

    try {
      const response = axios.post('https://webhook.site/9199bcae-84f4-463d-b3ce-8e6c831d1552',{
        firstName,lastName,email,phone
      });
      const result = (await response).data;
      console.log(result,'api reponse')
    }catch(error){
      console.error('error message',error)
    }

  };

  const handleReset = () => {
    setActiveStep(0);
    setCompleted(new Set());
    setSkipped(new Set());
  };

  const isStepSkipped = (step) => {
    return skipped.has(step);
  };

  function isStepComplete(step) {
    return completed.has(step);
  }

  return (
    <div className={classes.root}>
      <Stepper alternativeLabel nonLinear activeStep={activeStep}>
        {steps.map((label, index) => {
          const stepProps = {};
          const buttonProps = {};
          if (isStepOptional(index)) {
            buttonProps.optional = <Typography variant="caption">Optional</Typography>;
          }
          if (isStepSkipped(index)) {
            stepProps.completed = false;
          }
          return (
            <Step key={label} {...stepProps}>
              <StepButton
                onClick={handleStep(index)}
                completed={isStepComplete(index)}
                {...buttonProps}
              >
                {label}
              </StepButton>
            </Step>
          );
        })}
      </Stepper>
      <div>
        {allStepsCompleted() ? (
          <div>
            <Typography className={classes.instructions}>
              All steps completed - you&apos;re finished
            </Typography>
            <Button onClick={handleReset}>Reset</Button>
          </div>
        ) : (
          <div>
            <Typography className={classes.instructions}>{getStepContent(activeStep)}</Typography>
            <div>
              <Button disabled={activeStep === 0} onClick={handleBack} className={classes.button}>
                Back
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={handleNext}
                className={classes.button}
              >
                Next
              </Button>
              {isStepOptional(activeStep) && !completed.has(activeStep) && (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleSkip}
                  className={classes.button}
                >
                  Skip
                </Button>
              )}

              {activeStep !== steps.length &&
                (completed.has(activeStep) ? (
                  <Typography variant="caption" className={classes.completed}>
                    Step {activeStep + 1} already completed
                  </Typography>
                ) : (
                  <Button variant="contained" color="primary" onClick={handleComplete}>
                    {completedSteps() === totalSteps() - 1 ? 'Finish' : 'Complete Step'}
                  </Button>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
